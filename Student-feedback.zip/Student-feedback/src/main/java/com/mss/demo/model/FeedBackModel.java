package com.mss.demo.model;

public class FeedBackModel {
	private int id;
	private int academicYear;
	private int year;
	private int semester;
	private String branch;
	private String faculty;
	private int totalStudents;
	private String subject;

	private String knowledgeOfTheStudent;
	private String comingWellPreparedForTheClass;
	private String givingClearExplanations;
	private String commandOfLanguage;
	private String clearAndAudibleVoice;
	private String holdingTheAttentionOfStudentsThroughTheclass;
	private String providingMoreMatterThanIntheTextBook;
	private String capabilityToClearTheDoubtsOfStudents;
	private String encouragingStudentsToAskQuestionsAndParticipateInDiscussion;
	private String appreciatingStudentsAsAndWhenDeserving;
	private String willingnessToHelpStudentsEvenOutOfClass;
	private String returnOfValuedTestPapersRecordsIntime;
	private String punctualityAndFollowingTimeTableSchedule;
	private String coverageOfSyllabus;
	private String impartial;
	private int marks;
	public int getMarks() {
		return marks;
	}
	public void setMarks(int marks) {
		this.marks = marks;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getAcademicYear() {
		return academicYear;
	}
	public void setAcademicYear(int academicYear) {
		this.academicYear = academicYear;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public int getSemester() {
		return semester;
	}
	public void setSemester(int semester) {
		this.semester = semester;
	}
	public String getBranch() {
		return branch;
	}
	public void setBranch(String branch) {
		this.branch = branch;
	}
	public String getFaculty() {
		return faculty;
	}
	public void setFaculty(String faculty) {
		this.faculty = faculty;
	}
	public int getTotalStudents() {
		return totalStudents;
	}
	public void setTotalStudents(int totalStudents) {
		this.totalStudents = totalStudents;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getKnowledgeOfTheStudent() {
		return knowledgeOfTheStudent;
	}
	public void setKnowledgeOfTheStudent(String knowledgeOfTheStudent) {
		this.knowledgeOfTheStudent = knowledgeOfTheStudent;
	}
	public String getComingWellPreparedForTheClass() {
		return comingWellPreparedForTheClass;
	}
	public void setComingWellPreparedForTheClass(String comingWellPreparedForTheClass) {
		this.comingWellPreparedForTheClass = comingWellPreparedForTheClass;
	}
	public String getGivingClearExplanations() {
		return givingClearExplanations;
	}
	public void setGivingClearExplanations(String givingClearExplanations) {
		this.givingClearExplanations = givingClearExplanations;
	}
	public String getCommandOfLanguage() {
		return commandOfLanguage;
	}
	public void setCommandOfLanguage(String commandOfLanguage) {
		this.commandOfLanguage = commandOfLanguage;
	}
	public String getClearAndAudibleVoice() {
		return clearAndAudibleVoice;
	}
	public void setClearAndAudibleVoice(String clearAndAudibleVoice) {
		this.clearAndAudibleVoice = clearAndAudibleVoice;
	}
	public String getHoldingTheAttentionOfStudentsThroughTheclass() {
		return holdingTheAttentionOfStudentsThroughTheclass;
	}
	public void setHoldingTheAttentionOfStudentsThroughTheclass(String holdingTheAttentionOfStudentsThroughTheclass) {
		this.holdingTheAttentionOfStudentsThroughTheclass = holdingTheAttentionOfStudentsThroughTheclass;
	}
	public String getProvidingMoreMatterThanIntheTextBook() {
		return providingMoreMatterThanIntheTextBook;
	}
	public void setProvidingMoreMatterThanIntheTextBook(String providingMoreMatterThanIntheTextBook) {
		this.providingMoreMatterThanIntheTextBook = providingMoreMatterThanIntheTextBook;
	}
	public String getCapabilityToClearTheDoubtsOfStudents() {
		return capabilityToClearTheDoubtsOfStudents;
	}
	public void setCapabilityToClearTheDoubtsOfStudents(String capabilityToClearTheDoubtsOfStudents) {
		this.capabilityToClearTheDoubtsOfStudents = capabilityToClearTheDoubtsOfStudents;
	}
	public String getEncouragingStudentsToAskQuestionsAndParticipateInDiscussion() {
		return encouragingStudentsToAskQuestionsAndParticipateInDiscussion;
	}
	public void setEncouragingStudentsToAskQuestionsAndParticipateInDiscussion(
			String encouragingStudentsToAskQuestionsAndParticipateInDiscussion) {
		this.encouragingStudentsToAskQuestionsAndParticipateInDiscussion = encouragingStudentsToAskQuestionsAndParticipateInDiscussion;
	}
	public String getAppreciatingStudentsAsAndWhenDeserving() {
		return appreciatingStudentsAsAndWhenDeserving;
	}
	public void setAppreciatingStudentsAsAndWhenDeserving(String appreciatingStudentsAsAndWhenDeserving) {
		this.appreciatingStudentsAsAndWhenDeserving = appreciatingStudentsAsAndWhenDeserving;
	}
	public String getWillingnessToHelpStudentsEvenOutOfClass() {
		return willingnessToHelpStudentsEvenOutOfClass;
	}
	public void setWillingnessToHelpStudentsEvenOutOfClass(String willingnessToHelpStudentsEvenOutOfClass) {
		this.willingnessToHelpStudentsEvenOutOfClass = willingnessToHelpStudentsEvenOutOfClass;
	}
	public String getReturnOfValuedTestPapersRecordsIntime() {
		return returnOfValuedTestPapersRecordsIntime;
	}
	public void setReturnOfValuedTestPapersRecordsIntime(String returnOfValuedTestPapersRecordsIntime) {
		this.returnOfValuedTestPapersRecordsIntime = returnOfValuedTestPapersRecordsIntime;
	}
	public String getPunctualityAndFollowingTimeTableSchedule() {
		return punctualityAndFollowingTimeTableSchedule;
	}
	public void setPunctualityAndFollowingTimeTableSchedule(String punctualityAndFollowingTimeTableSchedule) {
		this.punctualityAndFollowingTimeTableSchedule = punctualityAndFollowingTimeTableSchedule;
	}
	public String getCoverageOfSyllabus() {
		return coverageOfSyllabus;
	}
	public void setCoverageOfSyllabus(String coverageOfSyllabus) {
		this.coverageOfSyllabus = coverageOfSyllabus;
	}
	public String getImpartial() {
		return impartial;
	}
	public void setImpartial(String impartial) {
		this.impartial = impartial;
	}

	

}
