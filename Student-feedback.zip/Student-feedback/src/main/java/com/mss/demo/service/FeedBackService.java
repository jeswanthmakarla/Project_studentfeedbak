package com.mss.demo.service;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Service;

import com.mss.demo.model.FeedBackModel;

@Service
public class FeedBackService {
	@Autowired
	JdbcTemplate jdbcTemplate;
//	
//	    public boolean saveFeedback(FeedBackModel feedBackModel) {
//	        String knowledgeOfTheStudent = feedBackModel.getKnowledgeOfTheStudent();
//	        switch (knowledgeOfTheStudent) {
//	            case "very good":
//	                System.out.println("Performing actions for 'very good' feedback...");
//	                break;
//	            case "good":
//	             
//	                System.out.println("Performing actions for 'good' feedback...");
//	               
//	                break;
//	            case "poor":
//	              
//	                System.out.println("Performing actions for 'poor' feedback...");
//	               
//	                break;
//	            case "average":
//	               
//	                System.out.println("Performing actions for 'average' feedback...");
//	               
//	                break;
//	            default:
//	               
//	                System.out.println("Invalid feedback value: " + knowledgeOfTheStudent);
//	              
//	                break;
//	        }
//			return false;
//	    }

	public boolean saveFeedback(FeedBackModel feedBackModel) {
		String sql = "INSERT INTO feedback (academicYear, year, semester, totalStudents, branch, faculty, subject, "
				+ "knowledgeOfTheStudent, comingWellPreparedForTheClass, givingClearExplanations, commandOfLanguage, "
				+ "clearAndAudibleVoice, holdingTheAttentionOfStudentsThroughTheclass, providingMoreMatterThanIntheTextBook, "
				+ "capabilityToClearTheDoubtsOfStudents, encouragingStudentsToAskQuestionsAndParticipateInDiscussion, "
				+ "appreciatingStudentsAsAndWhenDeserving, willingnessToHelpStudentsEvenOutOfClass, "
				+ "returnOfValuedTestPapersRecordsIntime, punctualityAndFollowingTimeTableSchedule, coverageOfSyllabus, "
				+ "impartial,marks) " + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

		int rowsAffected = jdbcTemplate.update(sql, feedBackModel.getAcademicYear(), feedBackModel.getYear(),
				feedBackModel.getSemester(), feedBackModel.getTotalStudents(), feedBackModel.getBranch(),
				feedBackModel.getFaculty(), feedBackModel.getSubject(), feedBackModel.getKnowledgeOfTheStudent(),
				feedBackModel.getComingWellPreparedForTheClass(), feedBackModel.getGivingClearExplanations(),
				feedBackModel.getCommandOfLanguage(), feedBackModel.getClearAndAudibleVoice(),
				feedBackModel.getHoldingTheAttentionOfStudentsThroughTheclass(),
				feedBackModel.getProvidingMoreMatterThanIntheTextBook(),
				feedBackModel.getCapabilityToClearTheDoubtsOfStudents(),
				feedBackModel.getEncouragingStudentsToAskQuestionsAndParticipateInDiscussion(),
				feedBackModel.getAppreciatingStudentsAsAndWhenDeserving(),
				feedBackModel.getWillingnessToHelpStudentsEvenOutOfClass(),
				feedBackModel.getReturnOfValuedTestPapersRecordsIntime(),
				feedBackModel.getPunctualityAndFollowingTimeTableSchedule(), feedBackModel.getCoverageOfSyllabus(),
				feedBackModel.getImpartial(), feedBackModel.getMarks());

		return rowsAffected > 0;
	}

	public List fetch() {
		List result1 = null;
		String Query = "select*from feedback";
		result1 = jdbcTemplate.queryForList(Query);
		return result1;
	}

	public List<Map<String, Object>> fetchById(int id) {
		String sql = "SELECT * FROM feedback WHERE id = ?";
		List<Map<String, Object>> result = jdbcTemplate.queryForList(sql, id);
		return result;
	}

}
