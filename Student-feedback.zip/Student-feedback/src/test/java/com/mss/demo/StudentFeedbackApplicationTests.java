package com.mss.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentFeedbackApplicationTests {

	@Test
	void contextLoads() {
	}

}
